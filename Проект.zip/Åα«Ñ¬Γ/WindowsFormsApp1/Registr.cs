﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp1          
{
    public partial class Registr : Form
    {
        
        public Registr()
        {
            InitializeComponent();
            textBox2.UseSystemPasswordChar = true;
            textBox3.UseSystemPasswordChar = true;
        }

        //ЗАКРЫТИЕ
        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //ПОКАЗ ПАРОЛЯ
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
                textBox3.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
                textBox3.UseSystemPasswordChar = true;
            }



        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        //КНОПКА ЗАРЕГЕСТРИРОВАТСЯ
        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Заполните все поля");
                return;
            }
            if (textBox2.Text != textBox3.Text)
            {
                MessageBox.Show("Пароли не совпадают");
                return;
            }
            RegisterUser(textBox1.Text, textBox2.Text);
            using (StreamWriter writer = new StreamWriter("Dor.txt", true))
            {

                writer.WriteLine($"{textBox1.Text}:{textBox2.Text}");

            }
            MessageBox.Show("Регистрация прошла успешно");
            this.Close();
        }
    
    
        //КНОПКА-У МЕНЯ ЕСТЬ АККАУНТ
        private void button3_Click(object sender, EventArgs e)
        {
            Login newForm = new Login();
            newForm.Show();
            Close();    
        }
        private void RegisterUser(string Login, string password)
        {

        }
        //ЗАБЕЙ НЕ РАБОТОЕТ
        private void button2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                button2.PerformClick();
            }
               
        }
    }
}
