﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//библиотеки


namespace WindowsFormsApp1
{
    
    public partial class Main : Form
    { 
        public Main()
        {
            InitializeComponent();
            
        }

        //блокирует кнопки: файлы и выхотд при открытии формы
        private void Form1_Load(object sender, EventArgs e)
        {
            Main form1 = Application.OpenForms.OfType<Main>().FirstOrDefault();
            if (form1 != null)
            {
                form1.MyMenuItem.Enabled = false;
                form1.Exit.Enabled = false;

            }
            
        }


     
       
        //кнопка входа
        private void входToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login newForm = new Login();
            newForm.Show();

        }


        //регистрация
        private void регистрацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Registr newForm = new Registr();
            newForm.Show();
        }



       

        //ИСПЛ ДЛЯ КНОПОК НА ДРУГИХ ФОРМАХ
        public ToolStripMenuItem MyMenuItem
        {
            get { return файлToolStripMenuItem; }
        }
        //ИСПЛ ДЛЯ КНОПОК НА ДРУГИХ ФОРМАХ
        public ToolStripMenuItem Login
        {
            get { return входToolStripMenuItem; }
        }
        //ИСПЛ ДЛЯ КНОПОК НА ДРУГИХ ФОРМАХ
        public ToolStripMenuItem Exit
        {
            get { return выходToolStripMenuItem; }
        }
        //ИСПЛ ДЛЯ КНОПОК НА ДРУГИХ ФОРМАХ
        public ToolStripMenuItem reg
        {
            get { return регистрацияToolStripMenuItem; }
        }
        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Main form1 = Application.OpenForms.OfType<Main>().FirstOrDefault();
            if (form1 != null)
            {
                form1.MyMenuItem.Enabled = false; //ФАЙЛ
                form1.Login.Enabled = true;
                form1.reg.Enabled = true;
                form1.Exit.Enabled = false;
            }
            MessageBox.Show("Вы вышли");
            
        }
       //ДЛЯ ПРАВКИ
        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
            {
                Form1 ch = (Form1)this.ActiveMdiChild;
                ch.richTextBox1.Paste();
                
                
            }
        }

        //ДЛЯ ПРАВКИ
        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 childForm = new Form1();
            childForm.MdiParent = this;
            childForm.Show();
            int n = this.MdiChildren.Count();
            childForm.Text = "Документ" + Convert.ToString(n);
            
        }
        //ДЛЯ ПРАВКИ
        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Rich Text File|*.rtf";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Form1 childForm = new Form1();
                childForm.richTextBox1.LoadFile(openFileDialog1.FileName);
                childForm.Text = openFileDialog1.FileName;
                childForm.MdiParent = this;
                childForm.Show();
            }
        }

        //ДЛЯ ПРАВКИ
        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
            {
                Form1 ch = (Form1)this.ActiveMdiChild;
                if (ch.richTextBox1.SelectionLength > 0)
                {
                    ch.richTextBox1.Copy();
                }
                


            }
        }
        //ДЛЯ ПРАВКИ
        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
            {
                Form1 ch = (Form1)this.ActiveMdiChild;
                if (ch.richTextBox1.SelectionLength > 0)
                {
                    ch.richTextBox1.Cut();
                }
            }
        }
        //ДЛЯ ПРАВКИ
        private void отменаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
            {
                Form1 ch = (Form1)this.ActiveMdiChild;
                ch.richTextBox1.Undo();
            }
        }
        //ПРАКТИКИ
        private void proga1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\1\1.docx");
        }
        //pr2
        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\2pr\2pr\bin\Debug\net6.0\zd1");
        }
        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\2pr\zd2\bin\Debug\net6.0\zd2");
        }

        //pr3
        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\3pr\3pr\bin\Debug\net6.0\zd1");
        }
        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\3pr\zd2\bin\Debug\net6.0\zd2");
        }
        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\3pr\zd3\bin\Debug\net6.0\zd3");
        }

        //pr4
        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\4pr\4pr\bin\Debug\4pr");
        }
        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\4pr\2zd\bin\Debug\2zd");
        }

        //pr5
        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\5pr\5pr\bin\Debug\5pr");
        }
        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\5pr\2zd\bin\Debug\2zd");
        }

        //pr6
        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\6pr\6pr\bin\Debug\6pr");
        }
        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\6pr\2zd\bin\Debug\2zd");
        }
        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\6pr\3zd\bin\Debug\3zd");
        }
        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\6pr\4zd\bin\Debug\4zd");
        }

        //pr7
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\7pr\7pr\bin\Debug\7pr");
        }
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\7pr\2zd\bin\Debug\2zd");
        }
        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\7pr\3\ConsoleApp1\zd3\bin\Debug\net6.0\zd3");
        }

        //pr8
        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\8pr\8pr\bin\Debug\8pr");
        }
        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\8pr\1zd(2)\bin\Debug\1zd(2)");
        }
        private void toolStripMenuItem20_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\8pr\1zd(3)\bin\Debug\1zd(3)");
        }
        private void toolStripMenuItem21_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\8pr\2zd\bin\Debug\2zd");
        }

        //pr9
        private void toolStripMenuItem22_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\9pr\9pr\9pr\bin\Debug\9pr");
        }
        private void toolStripMenuItem23_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\9pr\9pr\1zd(2)\bin\Debug\1zd(2)");
        }
        private void toolStripMenuItem24_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\9pr\9pr\2zd(1)\bin\Debug\2zd(1)");
        }
        private void toolStripMenuItem25_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\9pr\9pr\2zd(2)\bin\Debug\2zd(2)");
        }

        //pr10
        private void pr10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\10pr\10pr\10pr\bin\Debug\10pr");
        }

        //pr11
        private void toolStripMenuItem26_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\11pr\11pr\11pr\bin\Debug\11pr");
        }
        private void toolStripMenuItem27_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\11pr\11pr\2zd\bin\Debug\2zd");
        }

        //pr12
        private void pr12ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\12pr\12pr\12pr\bin\Debug\12pr");
        }

        //pr13
        private void pr13ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\13pr\13pr\bin\Debug\13pr");
        }

        //pr14
        private void pr14ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\14pr\14pr\14pr\bin\Debug\14pr");
        }

        //pr15
        private void pr15ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\15 калькулятор\WindowsFormsApp1\bin\Debug\WindowsFormsApp1");
        }

        //pr18
        private void pr16ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\16 редактор\bin\Debug\WindowsFormsApp68");
        }

        //pr17
        private void pr17ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\17 рисовалка\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\WindowsFormsApp1");
        }
        //pr18
        private void pr18ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\18 паинт\WindowsFormsApp1\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\WindowsFormsApp1");
        }

        //pr19
        private void серверToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\19 месенджер\WindowsFormsApp2\bin\Debug\Fopr");
        }
        private void клиентToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Проект\Проект\WindowsFormsApp1\bin\Debug\19 месенджер\WindowsFormsApp1\bin\Debug\WindowsFormsApp1");
        }
 
    }
}
